import pytest


@pytest.fixture
def sample_fixture():
    return {"key": "value"}
